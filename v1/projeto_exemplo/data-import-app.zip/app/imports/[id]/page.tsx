import { Calendar, Users, CheckCircle, Clock, Loader2, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"

// Mock data for demonstration
const importDetail = {
  id: "1",
  fileName: "2INFO4bim.xlsx",
  createdAt: "01/09 12:40",
  status: "Processando",
  overallStatus: 1, // 0: Aguardando, 1: Processando, 2: Finalizado, 3: Erro
  stages: [
    {
      name: "Registros",
      etapaId: null,
      status: 2, // 2: Concluída
      processedRows: 112,
      totalRows: 112,
    },
    {
      name: "Etapa 1",
      etapaId: 1,
      status: 2, // 2: Concluída
      processedRows: 112,
      totalRows: 112,
    },
    {
      name: "Etapa 2",
      etapaId: 2,
      status: 1, // 1: Em progresso
      processedRows: 54,
      totalRows: 112,
    },
    {
      name: "Etapa 3",
      etapaId: 3,
      status: 0, // 0: Aguardando
      processedRows: 0,
      totalRows: 112,
    },
    {
      name: "Etapa 4",
      etapaId: 4,
      status: 0, // 0: Aguardando
      processedRows: 0,
      totalRows: 112,
    },
  ],
}

function getStageIcon(status: number) {
  switch (status) {
    case 2: // Concluída
      return <CheckCircle className="h-4 w-4 text-primary" />
    case 1: // Em progresso
      return <Loader2 className="h-4 w-4 text-secondary animate-spin" />
    case 0: // Aguardando
      return <Clock className="h-4 w-4 text-muted-foreground" />
    default:
      return <Clock className="h-4 w-4 text-muted-foreground" />
  }
}

function getStageStatusText(status: number) {
  switch (status) {
    case 2:
      return "Concluída"
    case 1:
      return "Em progresso"
    case 0:
      return "Aguardando"
    default:
      return "Aguardando"
  }
}

function getOverallStatusText(status: number) {
  switch (status) {
    case 2:
      return "Finalizado"
    case 1:
      return "Processando"
    case 3:
      return "Erro"
    case 0:
      return "Aguardando"
    default:
      return "Aguardando"
  }
}

function getOverallStatusVariant(status: number): "default" | "secondary" | "destructive" {
  switch (status) {
    case 2:
      return "default"
    case 1:
      return "secondary"
    case 3:
      return "destructive"
    default:
      return "secondary"
  }
}

export default function ImportDetailPage({ params }: { params: { id: string } }) {
  const completedStages = importDetail.stages.filter((stage) => stage.status === 2).length
  const totalStages = importDetail.stages.length
  const overallProgress = (completedStages / totalStages) * 100

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6">
          <Link href="/imports">
            <Button variant="ghost" className="mb-4 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar para Lista
            </Button>
          </Link>

          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">{importDetail.fileName}</h1>
              <div className="flex items-center gap-4 text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span>Importado: {importDetail.createdAt}</span>
                </div>
              </div>
            </div>
            <Badge variant={getOverallStatusVariant(importDetail.overallStatus)} className="text-sm">
              {getOverallStatusText(importDetail.overallStatus)}
            </Badge>
          </div>
        </div>

        <div className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-card-foreground">Progresso Geral</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Etapas concluídas</span>
                  <span className="text-foreground">
                    {completedStages} de {totalStages}
                  </span>
                </div>
                <Progress value={overallProgress} className="h-2" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-card-foreground">Etapas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {importDetail.stages.map((stage, index) => (
                  <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      {getStageIcon(stage.status)}
                      <div>
                        <div className="font-medium text-foreground">{stage.name}</div>
                        <div className="text-sm text-muted-foreground">{getStageStatusText(stage.status)}</div>
                      </div>
                    </div>

                    <div className="text-right">
                      {stage.status === 2 && (
                        <div className="text-sm text-foreground">linhas: {stage.processedRows}</div>
                      )}
                      {stage.status === 1 && (
                        <div className="text-sm text-foreground">linhas: {stage.processedRows}</div>
                      )}
                      {stage.status === 1 && stage.totalRows && (
                        <div className="w-24 mt-1">
                          <Progress value={(stage.processedRows / stage.totalRows) * 100} className="h-1" />
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center">
            <Link href={`/imports/${params.id}/students`}>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Users className="h-4 w-4 mr-2" />
                Ver alunos desta planilha
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
