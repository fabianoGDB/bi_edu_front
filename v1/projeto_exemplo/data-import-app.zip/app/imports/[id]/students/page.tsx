import { Search, ArrowLeft, Eye, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import Link from "next/link"

// Mock data for demonstration
const importInfo = {
  id: "1",
  fileName: "2INFO4bim.xlsx",
  createdAt: "01/09",
}

const students = [
  {
    id: 1,
    nome: "ALICE SOUZA GUERRA SANTOS",
    matricula: "2023123",
  },
  {
    id: 2,
    nome: "ANA JULIA ALVES NORA",
    matricula: "2023555",
  },
  {
    id: 3,
    nome: "BEATRIZ F. DE OLIVEIRA SANTANA",
    matricula: "2023666",
  },
  {
    id: 4,
    nome: "CARLOS EDUARDO SILVA",
    matricula: "2023777",
  },
  {
    id: 5,
    nome: "DANIELA COSTA FERREIRA",
    matricula: "2023888",
  },
  {
    id: 6,
    nome: "EDUARDO SANTOS LIMA",
    matricula: "2023999",
  },
]

export default function StudentsFromImportPage({ params }: { params: { id: string } }) {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6">
          <Link href={`/imports/${params.id}`}>
            <Button variant="ghost" className="mb-4 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar para Detalhes
            </Button>
          </Link>

          <div className="flex items-center gap-3 mb-2">
            <Users className="h-6 w-6 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">Alunos da Planilha</h1>
          </div>
          <p className="text-muted-foreground">
            {importInfo.fileName} - Importado em {importInfo.createdAt}
          </p>
        </div>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-card-foreground">Lista de Alunos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por nome ou matrícula..."
                  className="pl-10 bg-input border-border text-foreground"
                />
              </div>
              <Select defaultValue="nome">
                <SelectTrigger className="w-full sm:w-48 bg-input border-border text-foreground">
                  <SelectValue placeholder="Ordenar por" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="nome">Nome</SelectItem>
                  <SelectItem value="matricula">Matrícula</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="rounded-md border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="border-border hover:bg-muted/50">
                    <TableHead className="w-12 text-muted-foreground">#</TableHead>
                    <TableHead className="text-muted-foreground">Nome</TableHead>
                    <TableHead className="text-muted-foreground">Matrícula</TableHead>
                    <TableHead className="w-20 text-muted-foreground">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map((student, index) => (
                    <TableRow key={student.id} className="border-border hover:bg-muted/50">
                      <TableCell className="font-medium text-foreground">{index + 1}</TableCell>
                      <TableCell className="text-foreground">{student.nome}</TableCell>
                      <TableCell className="text-foreground">{student.matricula}</TableCell>
                      <TableCell>
                        <Link href={`/students/${student.id}?importId=${params.id}`}>
                          <Button
                            variant="outline"
                            size="sm"
                            className="bg-transparent border-border text-foreground hover:bg-accent hover:text-accent-foreground"
                          >
                            <Eye className="h-3 w-3 mr-1" />
                            Ver
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
              <div>
                Mostrando {students.length} de {students.length} alunos
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled className="text-muted-foreground bg-transparent">
                  Anterior
                </Button>
                <Button variant="outline" size="sm" disabled className="text-muted-foreground bg-transparent">
                  Próximo
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
