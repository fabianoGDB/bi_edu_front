import { Calendar, Users, FileText, Clock, CheckCircle, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

// Mock data for demonstration
const imports = [
  {
    id: "1",
    fileName: "2INFO4bim.xlsx",
    createdAt: "01/09",
    students: 30,
    status: "Finalizado",
  },
  {
    id: "2",
    fileName: "Eng. Civil 2.xlsx",
    createdAt: "02/09",
    students: 0,
    status: "Processando",
  },
  {
    id: "3",
    fileName: "2INFO4bim.xlsx",
    createdAt: "03/09",
    students: 0,
    status: "Erro",
  },
]

function getStatusIcon(status: string) {
  switch (status) {
    case "Finalizado":
      return <CheckCircle className="h-4 w-4 text-primary" />
    case "Processando":
      return <Clock className="h-4 w-4 text-secondary" />
    case "Erro":
      return <XCircle className="h-4 w-4 text-destructive" />
    default:
      return <Clock className="h-4 w-4" />
  }
}

function getStatusVariant(status: string): "default" | "secondary" | "destructive" {
  switch (status) {
    case "Finalizado":
      return "default"
    case "Processando":
      return "secondary"
    case "Erro":
      return "destructive"
    default:
      return "default"
  }
}

export default function ImportsPage() {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Lista de Importações</h1>
          <p className="text-muted-foreground">Acompanhe o status das suas importações de dados</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {imports.map((importItem) => (
            <Card key={importItem.id} className="bg-card border-border hover:bg-card/80 transition-colors">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <CardTitle className="text-lg text-card-foreground truncate">{importItem.fileName}</CardTitle>
                  </div>
                  <Badge variant={getStatusVariant(importItem.status)} className="shrink-0">
                    {getStatusIcon(importItem.status)}
                    <span className="ml-1">{importItem.status}</span>
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>Importado em: {importItem.createdAt}</span>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>alunos: {importItem.students}</span>
                  </div>
                </div>

                <Link href={`/imports/${importItem.id}`}>
                  <Button
                    variant="outline"
                    className="w-full bg-transparent border-border text-card-foreground hover:bg-accent hover:text-accent-foreground"
                  >
                    Ver Detalhes
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 text-center">
          <Link href="/upload">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <FileText className="h-4 w-4 mr-2" />
              Nova Importação
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
