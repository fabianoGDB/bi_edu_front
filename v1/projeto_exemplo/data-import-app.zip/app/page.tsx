import { Upload, FileText, BarChart3 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-foreground mb-4">Sistema de Importação de Dados</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Importe e analise dados acadêmicos de forma eficiente com nossa plataforma integrada
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3 max-w-4xl mx-auto">
        <Card className="bg-card border-border hover:bg-accent/50 transition-colors">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <Upload className="h-5 w-5 text-primary" />
              Nova Importação
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Faça upload de planilhas Excel para processar dados acadêmicos
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/upload">
              <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                Importar Arquivo
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-card border-border hover:bg-accent/50 transition-colors">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <FileText className="h-5 w-5 text-primary" />
              Importações
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Visualize o status e gerencie suas importações de dados
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/imports">
              <Button variant="outline" className="w-full bg-transparent">
                Ver Importações
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-card border-border hover:bg-accent/50 transition-colors">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <BarChart3 className="h-5 w-5 text-primary" />
              Análise
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Acesse relatórios detalhados e análises de desempenho
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="w-full bg-transparent" disabled>
              Em Breve
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12 text-center">
        <div className="rounded-lg bg-muted p-6 max-w-2xl mx-auto">
          <h3 className="font-semibold text-foreground mb-2">Como funciona?</h3>
          <p className="text-sm text-muted-foreground">
            1. Faça upload da sua planilha Excel • 2. Acompanhe o processamento em tempo real • 3. Visualize os dados
            dos alunos e análises detalhadas
          </p>
        </div>
      </div>
    </div>
  )
}
