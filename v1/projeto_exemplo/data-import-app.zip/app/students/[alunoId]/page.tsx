import { ArrowLeft, User, FileText, BarChart3, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import Link from "next/link"

// Mock data for demonstration
const studentData = {
  id: 1,
  nome: "ALICE SOUZA GUERRA SANTOS",
  matricula: "2023123",
  importInfo: {
    fileName: "2INFO4bim.xlsx",
    date: "01/09",
  },
  fatos: [
    { disciplina: "INT.09889", periodoAvaliativoId: 1, nota: 8.5, situacao: "APR" },
    { disciplina: "INT.09889", periodoAvaliativoId: 2, nota: 9.4, situacao: "APR" },
    { disciplina: "INT.09889", periodoAvaliativoId: 3, nota: 9.1, situacao: "APR" },
    { disciplina: "INT.09889", periodoAvaliativoId: 4, nota: 8.5, situacao: "APR" },
    { disciplina: "INT.09890", periodoAvaliativoId: 1, nota: 8.0, situacao: "APR" },
    { disciplina: "MAT.12345", periodoAvaliativoId: 1, nota: 7.5, situacao: "APR" },
    { disciplina: "MAT.12345", periodoAvaliativoId: 2, nota: 8.2, situacao: "APR" },
    { disciplina: "MAT.12345", periodoAvaliativoId: 3, nota: 7.8, situacao: "APR" },
    { disciplina: "MAT.12345", periodoAvaliativoId: 4, nota: 8.1, situacao: "APR" },
    { disciplina: "FIS.67890", periodoAvaliativoId: 1, nota: 9.0, situacao: "APR" },
    { disciplina: "FIS.67890", periodoAvaliativoId: 2, nota: 8.7, situacao: "APR" },
    { disciplina: "FIS.67890", periodoAvaliativoId: 3, nota: 9.2, situacao: "APR" },
    { disciplina: "FIS.67890", periodoAvaliativoId: 4, nota: 8.9, situacao: "APR" },
  ],
  resumo: {
    frequenciaMedia: 98.3,
    totalDisciplinas: 15,
  },
}

function getSituacaoVariant(situacao: string): "default" | "secondary" | "destructive" {
  switch (situacao) {
    case "APR":
      return "default"
    case "REP":
      return "destructive"
    case "CAN":
    case "CUR":
    case "OUT":
      return "secondary"
    default:
      return "secondary"
  }
}

// Process data for charts
function processDataForCharts() {
  const disciplinas = [...new Set(studentData.fatos.map((f) => f.disciplina))]

  // Data for bar chart (average by evaluation period)
  const chartData = [1, 2, 3, 4].map((etapa) => {
    const notasEtapa = studentData.fatos.filter((f) => f.periodoAvaliativoId === etapa)
    const media = notasEtapa.length > 0 ? notasEtapa.reduce((sum, f) => sum + f.nota, 0) / notasEtapa.length : 0
    return {
      etapa: `E${etapa}`,
      media: Number(media.toFixed(1)),
    }
  })

  // Data for table
  const tableData = disciplinas.map((disciplina) => {
    const disciplinaFatos = studentData.fatos.filter((f) => f.disciplina === disciplina)
    const row: any = { disciplina }

    for (let i = 1; i <= 4; i++) {
      const fato = disciplinaFatos.find((f) => f.periodoAvaliativoId === i)
      row[`e${i}`] = fato ? fato.nota : null
    }

    const situacao = disciplinaFatos.length > 0 ? disciplinaFatos[0].situacao : "N/A"
    row.situacao = situacao

    return row
  })

  return { chartData, tableData }
}

export default function StudentDetailPage({
  params,
  searchParams,
}: {
  params: { alunoId: string }
  searchParams: { importId?: string }
}) {
  const { chartData, tableData } = processDataForCharts()

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6">
          <Link href={searchParams.importId ? `/imports/${searchParams.importId}/students` : "/imports"}>
            <Button variant="ghost" className="mb-4 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar para Lista
            </Button>
          </Link>

          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <User className="h-6 w-6 text-primary" />
                <h1 className="text-3xl font-bold text-foreground">{studentData.nome}</h1>
              </div>
              <div className="flex items-center gap-4 text-muted-foreground">
                <span>Matrícula: {studentData.matricula}</span>
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  <span>
                    Import: {studentData.importInfo.fileName} ({studentData.importInfo.date})
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <BarChart3 className="h-5 w-5" />
                Notas por Etapa
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="etapa" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} domain={[0, 10]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "6px",
                      color: "hsl(var(--card-foreground))",
                    }}
                  />
                  <Bar dataKey="media" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <TrendingUp className="h-5 w-5" />
                Resumo Acadêmico
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 rounded-lg bg-muted/50">
                  <div className="text-2xl font-bold text-primary">{studentData.resumo.frequenciaMedia}%</div>
                  <div className="text-sm text-muted-foreground">Frequência Média</div>
                </div>
                <div className="text-center p-4 rounded-lg bg-muted/50">
                  <div className="text-2xl font-bold text-primary">{studentData.resumo.totalDisciplinas}</div>
                  <div className="text-sm text-muted-foreground">Disciplinas</div>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium text-foreground">Performance Geral</h4>
                <div className="flex items-center gap-2">
                  <Badge variant="default">
                    Aprovado em {tableData.filter((d) => d.situacao === "APR").length} disciplinas
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6 bg-card border-border">
          <CardHeader>
            <CardTitle className="text-card-foreground">Detalhamento por Disciplina</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="border-border hover:bg-muted/50">
                    <TableHead className="text-muted-foreground">Disciplina</TableHead>
                    <TableHead className="text-center text-muted-foreground">E1</TableHead>
                    <TableHead className="text-center text-muted-foreground">E2</TableHead>
                    <TableHead className="text-center text-muted-foreground">E3</TableHead>
                    <TableHead className="text-center text-muted-foreground">E4</TableHead>
                    <TableHead className="text-center text-muted-foreground">Situação</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tableData.map((row, index) => (
                    <TableRow key={index} className="border-border hover:bg-muted/50">
                      <TableCell className="font-medium text-foreground">{row.disciplina}</TableCell>
                      <TableCell className="text-center text-foreground">
                        {row.e1 !== null ? row.e1.toFixed(1) : "-"}
                      </TableCell>
                      <TableCell className="text-center text-foreground">
                        {row.e2 !== null ? row.e2.toFixed(1) : "-"}
                      </TableCell>
                      <TableCell className="text-center text-foreground">
                        {row.e3 !== null ? row.e3.toFixed(1) : "-"}
                      </TableCell>
                      <TableCell className="text-center text-foreground">
                        {row.e4 !== null ? row.e4.toFixed(1) : "-"}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant={getSituacaoVariant(row.situacao)}>{row.situacao}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
