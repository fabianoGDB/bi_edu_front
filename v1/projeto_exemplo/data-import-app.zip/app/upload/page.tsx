import { Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function UploadPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mx-auto max-w-2xl">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-foreground mb-2">Importar Planilha</h1>
          <p className="text-muted-foreground">Faça upload de arquivos Excel para análise de dados acadêmicos</p>
        </div>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <Upload className="h-5 w-5" />
              Importar Planilha (.xlsx)
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Selecione um arquivo Excel para importar os dados dos alunos
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="file-upload" className="text-card-foreground">
                Escolher arquivo
              </Label>
              <Input
                id="file-upload"
                type="file"
                accept=".xlsx"
                className="bg-input border-border text-foreground file:bg-primary file:text-primary-foreground file:border-0 file:rounded-md file:px-3 file:py-1 file:mr-3"
              />
              <p className="text-sm text-muted-foreground">2INFO4bim.xlsx</p>
            </div>

            <div className="rounded-lg bg-muted p-4">
              <h3 className="font-medium text-foreground mb-2">Dicas:</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Somente .xlsx</li>
                <li>• Tamanho máx 20MB</li>
              </ul>
            </div>

            <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90" size="lg">
              Enviar
            </Button>

            <div className="rounded-lg bg-accent p-4 border border-accent">
              <div className="flex items-center gap-2 text-accent-foreground">
                <div className="h-2 w-2 rounded-full bg-primary"></div>
                <span className="font-medium">✔ Upload aceito. Job iniciado (#id).</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
